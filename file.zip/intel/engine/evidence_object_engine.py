# -*- coding: utf-8 -*-
"""
evidence_object_engine.py
Phase 2.4: Rich Evidence Objects Engine
Transforms simple rule evaluation outputs into rich evidence objects:
{
  "rule_id": "PRM_084",
  "supports": "Promotion",
  "confidence": 0.82,
  "strength": 76,
  "source": "Brihat Parashara Hora Shastra",
  "contradictions": [...],
  "dependencies": [...]
}
"""

from typing import Dict, List, Any

class RichEvidenceEngine:
    """Constructs rich, structured evidence objects for all evaluated rules."""

    @classmethod
    def create_evidence_object(
        cls,
        rule_id: str,
        supports_event: str,
        confidence: float,
        strength: int,
        source: str,
        positive_impact: bool,
        contradictions: List[str] = None,
        dependencies: List[str] = None
    ) -> Dict[str, Any]:

        return {
            "rule_id": rule_id,
            "supports": supports_event,
            "impact_type": "PROSECUTION_POSITIVE" if positive_impact else "DEFENSE_NEGATIVE",
            "confidence": confidence,
            "strength": strength,
            "source": source,
            "contradictions": contradictions or [],
            "dependencies": dependencies or []
        }
