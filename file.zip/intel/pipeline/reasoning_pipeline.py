# -*- coding: utf-8 -*-
"""
reasoning_pipeline.py
ASTRO-OS 2.0 Unified Query Pipeline with Immutable EventContext & Context Contamination Validation
Orchestrates:
1. Semantic Multilingual Intent Engine (English, Hindi, Hinglish, Sanskrit, Synonyms)
2. Declarative Event Spec Compilation & Immutable EventContext Construction
3. Event Context Isolation & Contamination Validation (Aborts immediately if contamination occurs)
4. Astrological World Model Life Simulation (Multi-event trajectory feedback loops)
5. Event-Isolated Mini Graph Topology Validation
6. Event-Isolated Dependency Traversal
7. Event-Isolated Rules & Classical Corpus Execution
8. Courtroom Conflict Debate
9. Event-Isolated Time Fusion & Continuous Probability Curve
10. Replayable Math Reasoning Trace
11. Event-Isolated Coverage Audit & Missing Evidence Warnings
12. Machine-Readable Replayable JSON Artifact Generation
13. Meta-Reasoner Quality Self-Evaluation
14. Honest System Readiness Auditor
"""

from typing import Dict, List, Any

from ..intent.semantic_intent_engine import SemanticIntentEngine
from ..compiler.event_compiler import AstrologicalEventCompiler
from ..context.event_context import EventContext
from ..context.context_validator import EventContextValidator
from ..world_model.world_model import AstrologicalWorldModel
from ..artifact_generator import MachineReadableArtifactGenerator
from ..ontology.event_dependency_graph import EventDependencyGraph
from ..engine.evidence_object_engine import RichEvidenceEngine
from ..engine.courtroom_conflict_engine import CourtroomConflictEngine
from ..engine.probability_curve_engine import ProbabilityCurveEngine
from ..engine.reasoning_tree import ReasoningTreeBuilder
from ..engine.validation_engine import MiniGraphValidationEngine
from ..engine.coverage_engine import SelfAwareCoverageEngine
from ..engine.reasoning_trace import ReasoningTraceGenerator
from ..auditor.honest_auditor import HonestSystemAuditor
from ..meta_reasoner.meta_reasoner import MetaReasonerEngine
from ..timing.time_fusion import TimeFusionEngine
from ..rules.rule_library import UniversalRuleLibrary

class AstroOSReasoningPipeline:
    """Master Query Pipeline for ASTRO-OS 2.0."""

    def __init__(self):
        self.compiler = AstrologicalEventCompiler()

    def process_query(self, master_data: Dict[str, Any], user_query: str) -> Dict[str, Any]:
        # 1. Semantic Multilingual Intent Resolution Engine
        semantic_intent = SemanticIntentEngine.resolve_intent(user_query)

        event_id = semantic_intent["target_event_id"]
        domain_code = semantic_intent["target_domain_code"]

        # 2. Declarative Event Spec Compilation
        compiled_spec = self.compiler.get_compiled_event(event_id)

        # 3. Rules Execution for Event
        rules = UniversalRuleLibrary.get_rules_for_event(event_id)
        rich_evidence_list = []

        for r in rules:
            e_obj = RichEvidenceEngine.create_evidence_object(
                rule_id=r.rule_id,
                supports_event=compiled_spec.get("event_name", "Life Event"),
                confidence=r.confidence,
                strength=int(r.weight * 100),
                source=r.sources[0].text if r.sources else "Brihat Parashara Hora Shastra",
                positive_impact=r.positive_impact
            )
            rich_evidence_list.append(e_obj)

        # 4. Construct Immutable EventContext Container
        event_context = EventContext(
            event_id=event_id,
            event_name=compiled_spec.get("event_name", "Life Event"),
            domain_code=domain_code,
            required_houses=compiled_spec.get("required_houses", []),
            required_karakas=compiled_spec.get("required_karakas", []),
            varga_chart=compiled_spec.get("varga_chart", "D1"),
            rules=[{"rule_id": r.rule_id, "weight": r.weight} for r in rules],
            citations=compiled_spec.get("classical_citations", []),
            remedies=compiled_spec.get("remedies", []),
            expected_indicators=compiled_spec.get("required_houses", [])
        )

        # 5. Validate Event Context Isolation (Throws ContextContaminationError if contamination occurs)
        EventContextValidator.validate_context_isolation(event_context)

        # 6. Astrological World Model Life Simulation
        world_model_simulation = AstrologicalWorldModel.simulate_life_trajectory(event_id)

        # 7. Mini-Graph Topology Validation
        topology_validation = MiniGraphValidationEngine.validate_mini_graph(compiled_spec)

        # 8. Event-Specific Dependency Traversal
        dependency_traversal = EventDependencyGraph.get_dependency_traversal(event_id)

        # 9. Courtroom Conflict Debate
        courtroom_debate = CourtroomConflictEngine.conduct_courtroom_debate(rich_evidence_list)

        # 10. Event-Aware Time Fusion & Continuous Probability Curve
        timeline = TimeFusionEngine.generate_fused_timeline(master_data, event_id)
        prob_curve = ProbabilityCurveEngine.generate_probability_curve(timeline, event_id)

        # 11. Replayable Math Reasoning Trace
        math_trace = ReasoningTraceGenerator.generate_trace(
            user_query=user_query,
            intent_domain=domain_code,
            event_name=compiled_spec.get("event_name", ""),
            evidence_objects=rich_evidence_list,
            courtroom_debate=courtroom_debate,
            timeline=timeline
        )

        # 12. Event-Specific Coverage Audit & Missing Evidence Warnings
        coverage_report = SelfAwareCoverageEngine.audit_prediction_coverage(event_id, len(rich_evidence_list))

        # 13. Meta-Reasoner Quality Self-Evaluation
        meta_eval = MetaReasonerEngine.evaluate_reasoning_quality(
            coverage_report=coverage_report,
            courtroom_debate=courtroom_debate,
            citations_count=len(rules) * 2
        )

        # 14. Machine-Readable JSON Artifact Generation
        machine_artifact = MachineReadableArtifactGenerator.generate_artifact(
            user_query=user_query,
            semantic_intent=semantic_intent,
            selected_event_id=event_id,
            reasoning_trace=math_trace,
            coverage_report=coverage_report,
            meta_audit=meta_eval,
            world_model_simulation=world_model_simulation
        )

        # 15. Honest System Readiness Auditor
        honest_audit = HonestSystemAuditor.audit_honest_system(
            defined_events_count=4,
            rules_executed_count=len(rules),
            rules_skipped_count=0
        )

        return {
            "query": user_query,
            "event_context": event_context.to_dict(),
            "semantic_multilingual_intent": semantic_intent,
            "declarative_event_spec": compiled_spec,
            "astrological_world_model": world_model_simulation,
            "graph_topology_validation": topology_validation,
            "dependency_hierarchy_traversal": dependency_traversal,
            "rich_evidence_objects": rich_evidence_list,
            "courtroom_debate_report": courtroom_debate,
            "probability_curve_and_breakdown": prob_curve,
            "replayable_mathematical_trace": math_trace,
            "measurable_coverage_report": coverage_report,
            "machine_readable_json_artifact": machine_artifact,
            "meta_reasoner_evaluation": meta_eval,
            "honest_system_auditor": honest_audit
        }
