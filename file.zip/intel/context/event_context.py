# -*- coding: utf-8 -*-
"""
event_context.py
ASTRO-OS 2.0 Immutable EventContext Container
Isolates rules, citations, remedies, indicators, and timing models per event.
Zero global variables, zero shared state, zero cached templates.
"""

from typing import Dict, List, Any
from dataclasses import dataclass, field

@dataclass(frozen=True)
class EventContext:
    event_id: str
    event_name: str
    domain_code: str
    required_houses: List[int]
    required_karakas: List[str]
    varga_chart: str
    rules: List[Dict[str, Any]]
    citations: List[Dict[str, Any]]
    remedies: List[Dict[str, Any]]
    expected_indicators: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_name": self.event_name,
            "domain_code": self.domain_code,
            "required_houses": self.required_houses,
            "required_karakas": self.required_karakas,
            "varga_chart": self.varga_chart,
            "rules_count": len(self.rules),
            "citations_count": len(self.citations),
            "remedies_count": len(self.remedies),
            "expected_indicators": self.expected_indicators
        }
