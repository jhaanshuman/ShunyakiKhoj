# -*- coding: utf-8 -*-
"""
context_validator.py
ASTRO-OS 2.0 Event Context Contamination Validator
Inspects the loaded EventContext before reasoning begins.
If cross-domain contamination is detected (e.g. Vehicle loading Childbirth rules or D7 chart),
throws ContextContaminationError and aborts reasoning immediately.
"""

from typing import Dict, List, Any
from .event_context import EventContext

class ContextContaminationError(Exception):
    """Raised when cross-domain template or rule contamination is detected."""
    pass

class EventContextValidator:
    """Validates EventContext isolation and prevents template leakage."""

    @classmethod
    def validate_context_isolation(cls, context: EventContext) -> bool:
        event_id = context.event_id.upper()
        domain = context.domain_code.upper()
        varga = context.varga_chart.upper()

        # Rule 1: Vehicle Event Validation
        if "VEHICLE" in event_id or "PROPERTY" in domain:
            if varga in ["D7", "D10", "D9"]:
                raise ContextContaminationError(f"Contamination Error: Vehicle event {event_id} loaded invalid Varga chart {varga} (Expected D4).")
            for r in context.rules:
                if "CHI_" in r.get("rule_id", "") or "MAR_" in r.get("rule_id", ""):
                    raise ContextContaminationError(f"Contamination Error: Vehicle event {event_id} loaded foreign rule {r.get('rule_id')}.")

        # Rule 2: Childbirth Event Validation
        if "CHILD" in event_id or "CHILDREN" in domain:
            if varga in ["D4", "D10"]:
                raise ContextContaminationError(f"Contamination Error: Childbirth event {event_id} loaded invalid Varga chart {varga} (Expected D7).")
            for r in context.rules:
                if "VEH_" in r.get("rule_id", "") or "FOR_" in r.get("rule_id", ""):
                    raise ContextContaminationError(f"Contamination Error: Childbirth event {event_id} loaded foreign rule {r.get('rule_id')}.")

        return True
