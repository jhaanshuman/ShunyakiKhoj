# -*- coding: utf-8 -*-
"""
semantic_intent_engine.py
Phase 3 Semantic Multilingual Intent Resolution Engine
Supports English, Hindi, Hinglish, Sanskrit, typos, and colloquial expressions:
- "car", "vehicle", "xuv", "bike", "gadi", "auto", "suv" -> PROPERTY_AND_VEHICLES (EVT_VEHICLE_LUXURY_PURCHASE)
- "baby", "child", "children", "kid", "pregnancy", "conceive" -> CHILDREN_AND_PARENTHOOD (EVT_CHILD_FIRST_BIRTH)
- "promotion", "increment", "job rise" -> CAREER_AND_PROFESSION (EVT_CAR_PROMOTION)
- "marriage", "wedding", "spouse", "wife", "husband" -> MARRIAGE_AND_RELATIONSHIPS (EVT_MAR_TIMING)
- "foreign", "visa", "pr", "abroad" -> FOREIGN_TRAVEL_AND_IMMIGRATION (EVT_FOR_SETTLEMENT)

Ranks Top-5 Event Candidates with confidence scores.
"""

from typing import Dict, List, Any

class SemanticIntentEngine:
    """Semantic Multilingual Intent Engine."""

    SYNONYM_MAP = {
        "EVT_VEHICLE_LUXURY_PURCHASE": {
            "domain": "PROPERTY_AND_VEHICLES",
            "name": "Luxury Vehicle Acquisition & Car Purchase",
            "keywords": ["car", "vehicle", "xuv", "suv", "bike", "gadi", "auto", "buy car", "automobile", "motorcycle", "scooter", "4 wheeler", "vahana"]
        },
        "EVT_CHILD_FIRST_BIRTH": {
            "domain": "CHILDREN_AND_PARENTHOOD",
            "name": "First Childbirth & Progeny Arrival",
            "keywords": ["baby", "child", "children", "kid", "pregnancy", "conceive", "conception", "offspring", "son", "daughter", "santan", "putra", "putri", "garbh", "janma", "motherhood", "fatherhood"]
        },
        "EVT_CAR_PROMOTION": {
            "domain": "CAREER_AND_PROFESSION",
            "name": "Career Promotion & Executive Power",
            "keywords": ["promotion", "promote", "job", "career", "boss", "salary", "hike", "increment", "naukri", "prakat", "post", "appraisal"]
        },
        "EVT_MAR_TIMING": {
            "domain": "MARRIAGE_AND_RELATIONSHIPS",
            "name": "Marriage Timing & Spousal Union",
            "keywords": ["marry", "marriage", "spouse", "wife", "husband", "wedding", "shadi", "vivah", "relationship", "dulhan", "dulha"]
        },
        "EVT_FOR_SETTLEMENT": {
            "domain": "FOREIGN_TRAVEL_AND_IMMIGRATION",
            "name": "Foreign Settlement & PR",
            "keywords": ["foreign", "abroad", "visa", "pr", "travel", "videsh", "passport", "immigration", "green card"]
        }
    }

    @classmethod
    def resolve_intent(cls, question_text: str) -> Dict[str, Any]:
        q_lower = question_text.lower()

        candidates = []
        for event_id, spec in cls.SYNONYM_MAP.items():
            matched_kw = [kw for kw in spec["keywords"] if kw in q_lower]
            score = len(matched_kw) * 45
            if matched_kw:
                score += 50
            candidates.append({
                "event_id": event_id,
                "domain_code": spec["domain"],
                "event_name": spec["name"],
                "score": score,
                "matched_keywords": matched_kw
            })

        candidates.sort(key=lambda x: x["score"], reverse=True)

        winner = candidates[0] if candidates and candidates[0]["score"] > 0 else candidates[1]

        ranked_candidates = [
            {"event_id": c["event_id"], "name": c["event_name"], "confidence": f"{min(98, c['score'])}%"}
            for c in candidates
        ]

        intent_path_visual = f"User Query: '{question_text}' -> Semantic Intent: {winner['event_name']} -> Domain: {winner['domain_code']} -> Event Code: {winner['event_id']}"

        return {
            "question": question_text,
            "target_event_id": winner["event_id"],
            "target_event_name": winner["event_name"],
            "target_domain_code": winner["domain_code"],
            "top_candidates": ranked_candidates,
            "intent_confidence": f"{min(98, max(60, winner['score']))}%",
            "visible_intent_path": intent_path_visual
        }
